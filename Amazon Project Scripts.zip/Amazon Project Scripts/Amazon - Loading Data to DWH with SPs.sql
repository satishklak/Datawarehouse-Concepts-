Use AmazonDW
go

if exists (select * from sys.procedures where name = 'usp_Load_DimProduct')
	drop proc usp_Load_DimProduct
go

create proc usp_Load_DimProduct
as
begin

Merge DimProduct as D
Using (SELECT pid, Name, Price, CategoryName FROM Amazon.dbo.ProductMaster as P JOIN Amazon.dbo.CategoryMaster as
 C on P.CategoryID =C.CategoryID) AS S ON D.ProductKey = s.pid

--update
When Matched and d.Productname <> s.name or  d.ProductPrice <> s.Price
 or d.Categoryname <> s.CategoryName
Then
update
set d.Productname = s.name ,  d.ProductPrice = s.Price , d.Categoryname =s.Categoryname

--insert
When Not Matched By Target
Then

Insert (ProductKey,Productname,ProductPrice, Categoryname)
 values (s.pid, s.name, s.price, s.Categoryname);

end;
go

--Exec usp_Load_DimProduct
--go
select * from DimProduct
go


if exists (select * from sys.procedures where name = 'usp_Load_DimCustomer')
	drop proc usp_Load_DimCustomer
go

create proc usp_Load_DimCustomer
as
begin

Merge DimCustomer as D
Using Amazon.dbo.CustomerMaster as S
On D.Customerkey = s.cid

--update
When Matched and d.CustomerName <> s.Name or d.CustomerCity <> S.City
Then
update
set d.CustomerName = s.Name ,  d.CustomerCity = s.City

--insert
When Not Matched By Target
Then
Insert (CustomerKey,Customername,CustomerCity) 
values (S.CID, S.name, S.City);
end;
go


--exec usp_Load_DimCustomer
--go


if exists (select * from sys.procedures where name = 'usp_Load_FactSales')
	drop proc usp_Load_FactSales
go

create proc usp_Load_FactSales
as
begin

--Full Loading
INSERT INTO FactSales
SELECT	PID,	
		CID,		
		SalesDateKey,	
		QtySold,	
		SalesAmount,	 
		DateKey as DeliveryDateKey, 
		LocationKey
FROM (
		SELECT PID,	CID,	SaleDate,	QtySold,	SalesAmount,	DeliveryDate,	DateKey as SalesDateKey
		FROM Amazon.dbo.Sales as S join DimTime as D on S.SaleDate = D.FullDate
	) as K
		join DimTime as D on  K.DeliveryDate = D.FullDate
		join DimCustomer as C on C.CustomerKey = K.CID
		join DimLocation as L on L.City = C.CustomerCity

end
go

--exec usp_Load_FactSales
--go

select * from DimCustomer
go

select * from DimLocation
go

select * from DimTime
go

select * from FactSales
go



