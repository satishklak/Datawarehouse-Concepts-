--staging Script
use master
go

create database AmazonStage
go

use AmazonStage
go

--Master Table
create table StageCategoryMaster
(
	CategoryID		smallint		not null,
	CategoryName	varchar(50)		not null
)
go

select * from StageCategoryMaster


--Master Table
create table StageProductMaster
(
	PID			int				not null,
	Name		varchar(40)		not null,
	Price		money			not null,
	CategoryID	smallint		not null 

)
go


--Master Table
create table StageCustomerMaster
(
	CID			int				not null,
	Name		varchar(40)		not null,
	City		varchar(50)		not null
)
go

create table StageSales
(
	PID			int				not null ,
	CID			int				not null, 
	SaleDate	datetime		not null,
	QtySold		int				not null,
	SalesAmount	money			not null,
	DeliveryDate	datetime	null
)
go

--Get all tables
use AmazonStage
go

select name from sys.tables
go

select 'SELECT * FROM '+ name from sys.tables
go


SELECT * FROM StageCategoryMaster

SELECT * FROM StageProductMaster

SELECT * FROM StageCustomerMaster

SELECT * FROM StageSales




 